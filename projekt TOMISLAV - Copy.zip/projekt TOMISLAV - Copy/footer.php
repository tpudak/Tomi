﻿<?php
# Stop Hacking attempt
if(!defined('__APP__')) {
	die("Hacking attempt");
}
?>
			<!-- Footer -->
			<footer id="footer">
				<div class="container">
					<section class="links">
						<div class="row">
							<section class="3u 6u(medium) 12u$(small)">
								<h3>Adresa</h3>
								<ul class="unstyled">
									<li><p>Adresa:</br>Zagrebačka 20</br>10000 Zagreb</br>T:+ 385 98 111 1111</p></li>
								
							<section class="3u 6u$(medium) 12u$(small)">
								<h3>Radno vrijeme</h3>
								<ul class="unstyled">
									<li><p>PON-PET : 08:00 - 17:00</br>SUB : 08:00 - 14:00</br>NED : Ne radimo ! </p></li>
								</ul>
							</section>


						</div>
					</section>
					<div class="row">
						<div class="8u 12u$(medium)">
							<ul class="copyright">
								<li>Copyright &copy; 2018 - TOMI PC d.o.o</li>
								<li>Izradio: <a href="mailto:tpudak@gmail.com">Tomislav Puđak</a></li>
							</ul>
						</div>
						<div class="4u$ 12u$(medium)">
							<ul class="icons">
								<li>
									<a class="icon rounded fa-facebook"><span class="label">Facebook</span></a>
								</li>
								<li>
									<a class="icon rounded fa-twitter"><span class="label">Twitter</span></a>
								</li>
								<li>
									<a class="icon rounded fa-google-plus"><span class="label">Google+</span></a>
								</li>
								<li>
									<a class="icon rounded fa-linkedin"><span class="label">LinkedIn</span></a>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</footer>