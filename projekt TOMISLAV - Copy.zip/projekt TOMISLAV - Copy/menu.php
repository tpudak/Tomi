<?php
	# Stop Hacking attempt
	if(!defined('__APP__')) {
		die("Hacking attempt");
	}
	?>
	
	<!-- Footer -->
	<footer id="footer">
		<div class="container">
			<ul class="copyright">
				<li>&copy; TOMI PC d.o.o design. <p>All rights reserved.</p></li>
				<li>Design: <a href="#" target="_blank">TOMI PC d.o.o</a></li>
				<li>Images: <a href="#" target="_blank">Unsplash</a></li>
			</ul>
		</div>
	</footer>